package com.dlsc.gmapsfx;

import javafx.scene.*;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import netscape.javascript.JSObject;
import javafx.geometry.Pos;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import com.dlsc.gmapsfx.javascript.event.UIEventType;
import com.dlsc.gmapsfx.javascript.object.Animation;
import com.dlsc.gmapsfx.javascript.object.DirectionsPane;
import com.dlsc.gmapsfx.javascript.object.GoogleMap;
import com.dlsc.gmapsfx.javascript.object.InfoWindow;
import com.dlsc.gmapsfx.javascript.object.InfoWindowOptions;
import com.dlsc.gmapsfx.javascript.object.LatLong;
import com.dlsc.gmapsfx.javascript.object.LatLongBounds;
import com.dlsc.gmapsfx.javascript.object.MVCArray;
import com.dlsc.gmapsfx.javascript.object.MapOptions;
import com.dlsc.gmapsfx.javascript.object.MapTypeIdEnum;
import com.dlsc.gmapsfx.javascript.object.Marker;
import com.dlsc.gmapsfx.javascript.object.MarkerOptions;
import com.dlsc.gmapsfx.service.directions.DirectionStatus;
import com.dlsc.gmapsfx.service.directions.DirectionsRenderer;
import com.dlsc.gmapsfx.service.directions.DirectionsRequest;
import com.dlsc.gmapsfx.service.directions.DirectionsResult;
import com.dlsc.gmapsfx.service.directions.DirectionsService;
import com.dlsc.gmapsfx.service.directions.DirectionsServiceCallback;
import com.dlsc.gmapsfx.service.directions.DirectionsWaypoint;
import com.dlsc.gmapsfx.service.directions.TravelModes;
import com.dlsc.gmapsfx.service.elevation.ElevationResult;
import com.dlsc.gmapsfx.service.elevation.ElevationService;
import com.dlsc.gmapsfx.service.elevation.ElevationServiceCallback;
import com.dlsc.gmapsfx.service.elevation.ElevationStatus;
import com.dlsc.gmapsfx.service.elevation.LocationElevationRequest;
import com.dlsc.gmapsfx.service.geocoding.GeocoderComponentRestrictions;
import com.dlsc.gmapsfx.service.geocoding.GeocoderRequest;
import com.dlsc.gmapsfx.service.geocoding.GeocoderStatus;
import com.dlsc.gmapsfx.service.geocoding.GeocodingResult;
import com.dlsc.gmapsfx.service.geocoding.GeocodingService;
import com.dlsc.gmapsfx.service.geocoding.GeocodingServiceCallback;
import com.dlsc.gmapsfx.shapes.ArcBuilder;
import com.dlsc.gmapsfx.shapes.Circle;
import com.dlsc.gmapsfx.shapes.CircleOptions;
import com.dlsc.gmapsfx.shapes.Polygon;
import com.dlsc.gmapsfx.shapes.PolygonOptions;
import com.dlsc.gmapsfx.shapes.Polyline;
import com.dlsc.gmapsfx.shapes.PolylineOptions;
import com.dlsc.gmapsfx.shapes.Rectangle;
import com.dlsc.gmapsfx.shapes.RectangleOptions;

import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class CapstoneProject extends Application implements MapComponentInitializedListener, 
ElevationServiceCallback, GeocodingServiceCallback, DirectionsServiceCallback{
	protected GoogleMapView mapComponent;
    protected GoogleMap map;
    protected DirectionsPane directions;

    private Button btnZoomIn;
    private Button btnZoomOut;
    private Label lblZoom;
    private Label lblCenter;
    private Label lblClick;
    private ComboBox<MapTypeIdEnum> mapTypeCombo;
	
	private MarkerOptions markerOptions2;
	private Marker myMarker2;
	private Button btnHideMarker;
	private Button btnDeleteMarker;
		@Override
	public void start(Stage stage) {
			//mapComponent = new GoogleMapView(Locale.getDefault().getLanguage(), null);
	        //mapComponent.addMapInitializedListener(this);
		MenuBar bar = new MenuBar();
		Menu operation = new Menu("My Fish Index");
		MenuItem exit = new MenuItem("Exit");
		MenuItem enter = new MenuItem("Enter a Fish:");
		MenuItem index = new MenuItem("Show Index: ");
		operation.getItems().addAll(enter, exit, index);
		
		bar.getMenus().add(operation);
		
		GridPane container = new GridPane();
		container.setVgap(3);
		
		Label fishName = new Label(String.format("%-30s", "Fish Name: "));
		TextField nameFish = new TextField();
		nameFish.setPrefColumnCount(3);
		container.add(fishName, 0, 1);
		container.add(nameFish, 1, 1);
		String names = nameFish.getText();
		
		Label fishLength = new Label(String.format("%-30s", "Fish Length: "));
		TextField lengthFish = new TextField();
		lengthFish.setPrefColumnCount(3);
		container.add(fishLength, 0, 2);
		container.add(lengthFish, 1, 2);
		String lengths = lengthFish.getText();
		
		Label fishWeight = new Label(String.format("%-30s", "Fish Weight: "));
		TextField weightFish = new TextField();
		
		weightFish.setPrefColumnCount(3);
		container.add(fishWeight, 0, 3);
		container.add(weightFish, 1, 3);
		String weights = weightFish.getText();
		
		Button location = new Button("Pick Location: ");
		container.add(location, 0, 4);
		
		
		Button stats = new Button("Save Stats");
		container.add(stats, 0, 5);
		HBox statsContain = new HBox(stats);
		statsContain.setAlignment(Pos.BOTTOM_LEFT);
		container.add(statsContain, 0, 6);		
		
		location = new Button("Show Location: ");
		container.add(location, 0, 4);
		location.setOnAction(e -> {
		mapComponent = new GoogleMapView(Locale.getDefault().getLanguage(), "AIzaSyB4ZuVcYIniSv5AzbCWMM3s6AgJE-aDO8s");
        mapComponent.addMapInitializedListener(this );
        container.add(mapComponent, 0, 5);
       //String locationText = locationText.getText();
//			WebView webView = new WebView();
//			webView.getEngine().load("http://maps.google.com");
//			container.add(webView, 2, 1);
		});
		
		VBox main = new VBox();
		main.setMinWidth(200);
		main.setMinHeight(200);
		container.add(bar, 0, 0);
		//container.setHgrow(Priority.ALWAYS);
		Scene scene = new Scene(container, 1000, 600);
		stage.setScene(scene);
		stage.setTitle("Exercise31_17");
		stage.show();
		
		//List<String[]> fishingLocations = new ArrayList<String[]>();
		
		String[] fishIndexed = new String[10];
		fishIndexed[0] = "a fish";
		
		String[] fishingLocations = new String[10];
		fishingLocations[0] = "Panguitch Lake";
		
		//actualLocations[0] = "PanguitchLake";
		
		//fishingLocations.set(0, fishIndexed);
		
		ComboBox<String> fishing = new ComboBox();
		
		fishing.getItems().add(fishingLocations[0]);
		container.add(fishing, 1, 4);

		//
		//fishindexed.add(new String[] {names, lengths, weights});
		
		
		
		EventHandler<ActionEvent> eventStat = e -> {
			double length, weight;
			try {
				String name = nameFish.getText().trim();
				length = Double.parseDouble(lengthFish.getText().trim());
				weight = Double.parseDouble(weightFish.getText().trim());
				System.out.println("Your Fish Stats: ");
				Label printed = new Label(String.format("%-30s", "Fish Name: " + name + "  Fish Length: " + length + " Fish Weight: " + weight + " Location: " + "Panguitch Lake"));
				container.add(printed, 0, 7);
			}
			catch(Exception exception) {
				Label nonPrint = new Label (String.format("%-30s", "Input is not valid please type in a valid value."));
				container.add(nonPrint, 0, 8);
				
//				String googlemaps = new String();
//				final String GOOGLE_MAPS_API_LINK = "https://maps.googleapis.com/maps/api/AIzaSyA_ozwkGsAe-l1PSYO-cV8nlb7Q42d-wNI\r\n";
				
			}
		};
		stats.setOnAction(eventStat);
		enter.setOnAction(eventStat);
		
		exit.setOnAction(e -> System.exit(0));
		//index.setOnAction(e -> );
		
		
	}
//	public static void main(String[] args) {
//	    launch(args);
//	  }
DirectionsRenderer renderer;
    
    @Override
    public void mapInitialized() {
        
        //System.out.println("MainApp.mapInitialised....");
        
        //Once the map has been loaded by the Webview, initialize the map details.
       // LatLong center = new LatLong(37.6775, -113.0619);
        LatLong center = new LatLong(37.7143, -112.6407);
        
        mapComponent.addMapReadyListener(() -> {
            // This call will fail unless the map is completely ready.
            checkCenter(center);
        });
        
        //switch on their selection
        
        MapOptions options = new MapOptions();
        options.center(center)
                .mapMarker(true)
                .zoom(14)
                .overviewMapControl(false)
                .streetViewControl(false)
                .mapType(MapTypeIdEnum.TERRAIN)
                .styleString("[{'featureType':'landscape','stylers':[{'saturation':-100},{'lightness':65},{'visibility':'on'}]},{'featureType':'poi','stylers':[{'saturation':-100},{'lightness':51},{'visibility':'simplified'}]},{'featureType':'road.highway','stylers':[{'saturation':-100},{'visibility':'simplified'}]},{\"featureType\":\"road.arterial\",\"stylers\":[{\"saturation\":-100},{\"lightness\":30},{\"visibility\":\"on\"}]},{\"featureType\":\"road.local\",\"stylers\":[{\"saturation\":-100},{\"lightness\":40},{\"visibility\":\"on\"}]},{\"featureType\":\"transit\",\"stylers\":[{\"saturation\":-100},{\"visibility\":\"simplified\"}]},{\"featureType\":\"administrative.province\",\"stylers\":[{\"visibility\":\"off\"}]},{\"featureType\":\"water\",\"elementType\":\"labels\",\"stylers\":[{\"visibility\":\"on\"},{\"lightness\":-25},{\"saturation\":-100}]},{\"featureType\":\"water\",\"elementType\":\"geometry\",\"stylers\":[{\"hue\":\"#ffff00\"},{\"lightness\":-25},{\"saturation\":-97}]}]");
        
        //[{\"featureType\":\"landscape\",\"stylers\":[{\"saturation\":-100},{\"lightness\":65},{\"visibility\":\"on\"}]},{\"featureType\":\"poi\",\"stylers\":[{\"saturation\":-100},{\"lightness\":51},{\"visibility\":\"simplified\"}]},{\"featureType\":\"road.highway\",\"stylers\":[{\"saturation\":-100},{\"visibility\":\"simplified\"}]},{\"featureType\":\"road.arterial\",\"stylers\":[{\"saturation\":-100},{\"lightness\":30},{\"visibility\":\"on\"}]},{\"featureType\":\"road.local\",\"stylers\":[{\"saturation\":-100},{\"lightness\":40},{\"visibility\":\"on\"}]},{\"featureType\":\"transit\",\"stylers\":[{\"saturation\":-100},{\"visibility\":\"simplified\"}]},{\"featureType\":\"administrative.province\",\"stylers\":[{\"visibility\":\"off\"}]},{\"featureType\":\"water\",\"elementType\":\"labels\",\"stylers\":[{\"visibility\":\"on\"},{\"lightness\":-25},{\"saturation\":-100}]},{\"featureType\":\"water\",\"elementType\":\"geometry\",\"stylers\":[{\"hue\":\"#ffff00\"},{\"lightness\":-25},{\"saturation\":-97}]}]
        //options.center(panguitchLake);
        map = mapComponent.createMap(options);
        directions = mapComponent.getDirec();
//        GeocoderRequest geo = new GeocoderRequest("0 North 0 West", center, null, null, null, null);
//        System.out.println(geo.getAddress());
       
//        
//        map.setHeading(123.2);
////        System.out.println("Heading is: " + map.getHeading() );
//
//        MarkerOptions markerOptions = new MarkerOptions();
//        LatLong markerLatLong = new LatLong(47.606189, -122.335842);
//        markerOptions.position(markerLatLong)
//                .title("My new Marker")
//                .icon("mymarker.png")
//                .animation(Animation.DROP)
//                .visible(true);
//
//        final Marker myMarker = new Marker(markerOptions);
//
//        markerOptions2 = new MarkerOptions();
//        LatLong markerLatLong2 = new LatLong(47.906189, -122.335842);
//        markerOptions2.position(markerLatLong2)
//                .title("My new Marker")
//                .visible(true);
//
//        myMarker2 = new Marker(markerOptions2);
//
//        map.addMarker(myMarker);
//        map.addMarker(myMarker2);
//
//        InfoWindowOptions infoOptions = new InfoWindowOptions();
//        infoOptions.content("<h2>Here's an info window</h2><h3>with some info</h3>")
//                .position(center);
//
//        InfoWindow window = new InfoWindow(infoOptions);
//        window.open(map, myMarker);
//        
//        
//        map.fitBounds(new LatLongBounds(new LatLong(30, 120), center));
////        System.out.println("Bounds : " + map.getBounds());
//
//        lblCenter.setText(map.getCenter().toString());
//        map.centerProperty().addListener((ObservableValue<? extends LatLong> obs, LatLong o, LatLong n) -> {
//            lblCenter.setText(n.toString());
//        });
//
//        lblZoom.setText(Integer.toString(map.getZoom()));
//        map.zoomProperty().addListener((ObservableValue<? extends Number> obs, Number o, Number n) -> {
//            lblZoom.setText(n.toString());
//        });
//
////      map.addStateEventHandler(MapStateEventType.center_changed, () -> {
////			System.out.println("center_changed: " + map.getCenter());
////		});
////        map.addStateEventHandler(MapStateEventType.tilesloaded, () -> {
////			System.out.println("We got a tilesloaded event on the map");
////		});
//
//  
//        map.addUIEventHandler(UIEventType.click, (JSObject obj) -> {
//            LatLong ll = new LatLong((JSObject) obj.getMember("latLng"));
//            System.out.println("LatLong: lat: " + ll.getLatitude() + " lng: " + ll.getLongitude());
//            lblClick.setText(ll.toString());
//        });
//
//        btnZoomIn.setDisable(false);
//        btnZoomOut.setDisable(false);
//        mapTypeCombo.setDisable(false);
//        
//        mapTypeCombo.getItems().addAll( MapTypeIdEnum.ALL );
//
//        LatLong[] ary = new LatLong[]{markerLatLong, markerLatLong2};
//        MVCArray mvc = new MVCArray(ary);
//
//        PolylineOptions polyOpts = new PolylineOptions()
//                .path(mvc)
//                .strokeColor("red")
//                .strokeWeight(2);
//
//        Polyline poly = new Polyline(polyOpts);
//        map.addMapShape(poly);
//        map.addUIEventHandler(poly, UIEventType.click, (JSObject obj) -> {
//            LatLong ll = new LatLong((JSObject) obj.getMember("latLng"));
////            System.out.println("You clicked the line at LatLong: lat: " + ll.getLatitude() + " lng: " + ll.getLongitude());
//        });
//
//        LatLong poly1 = new LatLong(47.429945, -122.84363);
//        LatLong poly2 = new LatLong(47.361153, -123.03040);
//        LatLong poly3 = new LatLong(47.387193, -123.11554);
//        LatLong poly4 = new LatLong(47.585789, -122.96722);
//        LatLong[] pAry = new LatLong[]{poly1, poly2, poly3, poly4};
//        MVCArray pmvc = new MVCArray(pAry);
//
//        PolygonOptions polygOpts = new PolygonOptions()
//                .paths(pmvc)
//                .strokeColor("blue")
//                .strokeWeight(2)
//                .editable(false)
//                .fillColor("lightBlue")
//                .fillOpacity(0.5);
//
//        Polygon pg = new Polygon(polygOpts);
//        map.addMapShape(pg);
//        map.addUIEventHandler(pg, UIEventType.click, (JSObject obj) -> {
//            //polygOpts.editable(true);
//            pg.setEditable(!pg.getEditable());
//        });
//
//        LatLong centreC = new LatLong(47.545481, -121.87384);
//        CircleOptions cOpts = new CircleOptions()
//                .center(centreC)
//                .radius(5000)
//                .strokeColor("green")
//                .strokeWeight(2)
//                .fillColor("orange")
//                .fillOpacity(0.3);
//
//        Circle c = new Circle(cOpts);
//        map.addMapShape(c);
//        map.addUIEventHandler(c, UIEventType.click, (JSObject obj) -> {
//            c.setEditable(!c.getEditable());
//        });
//
//        LatLongBounds llb = new LatLongBounds(new LatLong(47.533893, -122.89856), new LatLong(47.580694, -122.80312));
//        RectangleOptions rOpts = new RectangleOptions()
//                .bounds(llb)
//                .strokeColor("black")
//                .strokeWeight(2)
//                .fillColor("null");
//
//        Rectangle rt = new Rectangle(rOpts);
//        map.addMapShape(rt);
//
//        LatLong arcC = new LatLong(47.227029, -121.81641);
//        double startBearing = 0;
//        double endBearing = 30;
//        double radius = 30000;
//
//        MVCArray path = ArcBuilder.buildArcPoints(arcC, startBearing, endBearing, radius);
//        path.push(arcC);
//
//        Polygon arc = new Polygon(new PolygonOptions()
//                .paths(path)
//                .strokeColor("blue")
//                .fillColor("lightBlue")
//                .fillOpacity(0.3)
//                .strokeWeight(2)
//                .editable(false));
//
//        map.addMapShape(arc);
//        map.addUIEventHandler(arc, UIEventType.click, (JSObject obj) -> {
//            arc.setEditable(!arc.getEditable());
//        });
//        
//        GeocodingService gs = new GeocodingService();
//        
//        DirectionsService ds = new DirectionsService();
//        renderer = new DirectionsRenderer(true, map, directions);
//        
//        DirectionsWaypoint[] dw = new DirectionsWaypoint[2];
//        dw[0] = new DirectionsWaypoint("São Paulo - SP");
//        dw[1] = new DirectionsWaypoint("Juiz de Fora - MG");
//        
//        DirectionsRequest dr = new DirectionsRequest(
//                "Belo Horizonte - MG",
//                "Rio de Janeiro - RJ",
//                TravelModes.DRIVING,
//                dw, false);
//        ds.getRoute(dr, this, renderer);
//        
//        LatLong[] location = new LatLong[1];
//        location[0] = new LatLong(-19.744056, -43.958699);
//        LocationElevationRequest loc = new LocationElevationRequest(location);
//        ElevationService es = new ElevationService();
//        es.getElevationForLocations(loc, this);
//        
    }
    
    

	
	
	private void hideMarker() {
//		System.out.println("deleteMarker");
		
		boolean visible = myMarker2.getVisible();
		
		//System.out.println("Marker was visible? " + visible);
		
		myMarker2.setVisible(! visible);

//				markerOptions2.visible(Boolean.FALSE);
//				myMarker2.setOptions(markerOptions2);
//		System.out.println("deleteMarker - made invisible?");
	}
	
	private void deleteMarker() {
		//System.out.println("Marker was removed?");
		map.removeMarker(myMarker2);
	}
	
    private void checkCenter(LatLong center) {
//        System.out.println("Testing fromLatLngToPoint using: " + center);
//        Point2D p = map.fromLatLngToPoint(center);
//        System.out.println("Testing fromLatLngToPoint result: " + p);
//        System.out.println("Testing fromLatLngToPoint expected: " + mapComponent.getWidth()/2 + ", " + mapComponent.getHeight()/2);
    }
    
    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.setProperty("java.net.useSystemProxies", "true");
        launch(args);
    }

    @Override
    public void elevationsReceived(ElevationResult[] results, ElevationStatus status) {
        if(status.equals(ElevationStatus.OK)){
            for(ElevationResult e : results){
                System.out.println(" Elevation on "+ e.getLocation().toString() + " is " + e.getElevation());
            }
        }
    }

    @Override
    public void geocodedResultsReceived(GeocodingResult[] results, GeocoderStatus status) {
        if(status.equals(GeocoderStatus.OK)){
            for(GeocodingResult e : results){
                System.out.println(e.getVariableName());
                System.out.println("GEOCODE: " + e.getFormattedAddress() + "\n" + e.toString());
            }
            
        }
        
    }

    @Override
    public void directionsReceived(DirectionsResult results, DirectionStatus status) {
        if(status.equals(DirectionStatus.OK)){
            mapComponent.getMap().showDirectionsPane();
            System.out.println("OK");
            
            DirectionsResult e = results;
            GeocodingService gs = new GeocodingService();
            
            System.out.println("SIZE ROUTES: " + e.getRoutes().size() + "\n" + "ORIGIN: " + e.getRoutes().get(0).getLegs().get(0).getStartLocation());
            //gs.reverseGeocode(e.getRoutes().get(0).getLegs().get(0).getStartLocation().getLatitude(), e.getRoutes().get(0).getLegs().get(0).getStartLocation().getLongitude(), this);
            System.out.println("LEGS SIZE: " + e.getRoutes().get(0).getLegs().size());
            System.out.println("WAYPOINTS " +e.getGeocodedWaypoints().size());
            /*double d = 0;
            for(DirectionsLeg g : e.getRoutes().get(0).getLegs()){
                d += g.getDistance().getValue();
                System.out.println("DISTANCE " + g.getDistance().getValue());
            }*/
            try{
                System.out.println("Distancia total = " + e.getRoutes().get(0).getLegs().get(0).getDistance().getText());
            } catch(Exception ex){
                System.out.println("ERRO: " + ex.getMessage());
            }
            System.out.println("LEG(0)");
            System.out.println(e.getRoutes().get(0).getLegs().get(0).getSteps().size());
            /*for(DirectionsSteps ds : e.getRoutes().get(0).getLegs().get(0).getSteps()){
                System.out.println(ds.getStartLocation().toString() + " x " + ds.getEndLocation().toString());
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(ds.getStartLocation())
                        .title(ds.getInstructions())
                        .animation(Animation.DROP)
                        .visible(true);
                Marker myMarker = new Marker(markerOptions);
                map.addMarker(myMarker);
            }
                    */
            System.out.println(renderer.toString());
        }
    }
}
